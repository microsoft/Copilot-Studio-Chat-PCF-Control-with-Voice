/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./OpportunitySummary/index.ts":
/*!*************************************!*\
  !*** ./OpportunitySummary/index.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   OpportunitySummary: () => (/* binding */ OpportunitySummary)\n/* harmony export */ });\nclass OpportunitySummary {\n  constructor() {\n    // Constructor logic if needed\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = container;\n    this.createSummaryCard();\n  }\n  createSummaryCard() {\n    // Main container\n    this._summaryContainer = document.createElement(\"div\");\n    this._summaryContainer.className = \"opportunity-summary\";\n    // Header section\n    this._headerElement = document.createElement(\"div\");\n    this._headerElement.className = \"opportunity-header\";\n    this._titleElement = document.createElement(\"h3\");\n    this._titleElement.className = \"opportunity-title\";\n    this._titleElement.textContent = \"Opportunity Summary\";\n    this._periodElement = document.createElement(\"p\");\n    this._periodElement.className = \"opportunity-period\";\n    this._periodElement.textContent = \"Last 12 Months\";\n    this._headerElement.appendChild(this._titleElement);\n    this._headerElement.appendChild(this._periodElement);\n    // Metrics container\n    this._metricsContainer = document.createElement(\"div\");\n    this._metricsContainer.className = \"opportunity-metrics\";\n    // Create individual metric cards\n    this._wonMetric = this.createMetricElement(\"won\");\n    this._lostMetric = this.createMetricElement(\"lost\");\n    this._openMetric = this.createMetricElement(\"open\");\n    this._metricsContainer.appendChild(this._wonMetric);\n    this._metricsContainer.appendChild(this._lostMetric);\n    this._metricsContainer.appendChild(this._openMetric);\n    // Assemble the card\n    this._summaryContainer.appendChild(this._headerElement);\n    this._summaryContainer.appendChild(this._metricsContainer);\n    this._container.appendChild(this._summaryContainer);\n  }\n  createMetricElement(type) {\n    var metricElement = document.createElement(\"div\");\n    metricElement.className = \"opportunity-metric \".concat(type);\n    var metricValue = document.createElement(\"div\");\n    metricValue.className = \"metric-value\";\n    metricValue.textContent = \"0\";\n    var metricLabel = document.createElement(\"div\");\n    metricLabel.className = \"metric-label\";\n    metricElement.appendChild(metricValue);\n    metricElement.appendChild(metricLabel);\n    return metricElement;\n  }\n  updateView(context) {\n    var _a, _b;\n    this._context = context;\n    // Get opportunity values\n    var wonOpportunities = context.parameters.wonOpportunities.raw || 0;\n    var lostOpportunities = context.parameters.lostOpportunities.raw || 0;\n    var openOpportunities = context.parameters.openOpportunities.raw || 0;\n    // Get labels\n    var wonLabel = context.parameters.wonLabel.raw || \"WON OPPS\";\n    var lostLabel = context.parameters.lostLabel.raw || \"LOST OPPS\";\n    var openLabel = context.parameters.openLabel.raw || \"OPEN OPPS\";\n    // Get display settings\n    var cardTitle = context.parameters.cardTitle.raw || \"Opportunity Summary\";\n    var timePeriodLabel = context.parameters.timePeriodLabel.raw || \"Last 12 Months\";\n    var colorTheme = context.parameters.colorTheme.raw || \"green\";\n    var backgroundStyle = ((_a = context.parameters.backgroundStyle) === null || _a === void 0 ? void 0 : _a.raw) || \"gradient\";\n    var cardHeight = ((_b = context.parameters.cardHeight) === null || _b === void 0 ? void 0 : _b.raw) || 280;\n    // Update header\n    this._titleElement.textContent = cardTitle;\n    this._periodElement.textContent = timePeriodLabel;\n    // Update metric values and labels\n    var wonValueEl = this._wonMetric.querySelector('.metric-value');\n    var wonLabelEl = this._wonMetric.querySelector('.metric-label');\n    wonValueEl.textContent = this.formatNumber(wonOpportunities);\n    wonLabelEl.textContent = wonLabel;\n    var lostValueEl = this._lostMetric.querySelector('.metric-value');\n    var lostLabelEl = this._lostMetric.querySelector('.metric-label');\n    lostValueEl.textContent = this.formatNumber(lostOpportunities);\n    lostLabelEl.textContent = lostLabel;\n    var openValueEl = this._openMetric.querySelector('.metric-value');\n    var openLabelEl = this._openMetric.querySelector('.metric-label');\n    openValueEl.textContent = this.formatNumber(openOpportunities);\n    openLabelEl.textContent = openLabel;\n    // Apply styling and height\n    this.applyStyling(colorTheme, backgroundStyle, cardHeight);\n    // Calculate win rate for additional context\n    var totalClosed = wonOpportunities + lostOpportunities;\n    var winRate = totalClosed > 0 ? (wonOpportunities / totalClosed * 100).toFixed(1) : 0;\n    // Debug logging\n    console.log(\"=== Opportunity Summary Debug Info ===\");\n    console.log(\"Opportunities:\", {\n      won: wonOpportunities,\n      lost: lostOpportunities,\n      open: openOpportunities\n    });\n    console.log(\"Win Rate:\", \"\".concat(winRate, \"%\"));\n    console.log(\"Total Closed:\", totalClosed);\n    console.log(\"Labels:\", {\n      wonLabel,\n      lostLabel,\n      openLabel\n    });\n  }\n  formatNumber(value) {\n    if (value === null || value === undefined) {\n      return \"0\";\n    }\n    // Format large numbers with commas\n    return value.toLocaleString();\n  }\n  applyStyling(colorTheme, backgroundStyle, cardHeight) {\n    // Remove existing style classes\n    var themeClasses = [\"theme-blue\", \"theme-green\", \"theme-orange\", \"theme-purple\", \"theme-red\"];\n    var backgroundClasses = [\"bg-white\", \"bg-clear\"];\n    [...themeClasses, ...backgroundClasses].forEach(cls => this._summaryContainer.classList.remove(cls));\n    // Apply background style\n    var normalizedBackground = (backgroundStyle === null || backgroundStyle === void 0 ? void 0 : backgroundStyle.toLowerCase().trim()) || \"gradient\";\n    if (normalizedBackground === \"white\") {\n      this._summaryContainer.classList.add(\"bg-white\");\n    } else if (normalizedBackground === \"clear\") {\n      this._summaryContainer.classList.add(\"bg-clear\");\n    }\n    // Apply color theme\n    var normalizedTheme = (colorTheme === null || colorTheme === void 0 ? void 0 : colorTheme.toLowerCase().trim()) || \"green\";\n    if (themeClasses.includes(\"theme-\".concat(normalizedTheme))) {\n      this._summaryContainer.classList.add(\"theme-\".concat(normalizedTheme));\n    } else {\n      this._summaryContainer.classList.add(\"theme-green\"); // Default theme for opportunities\n    }\n    // Apply card height\n    var height = cardHeight && cardHeight > 0 ? cardHeight : 280;\n    this._summaryContainer.style.minHeight = \"\".concat(height, \"px\");\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    // Cleanup logic if needed\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./OpportunitySummary/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./OpportunitySummary/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('BillWhalen.Controls.OpportunitySummary', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.OpportunitySummary);
} else {
	var BillWhalen = BillWhalen || {};
	BillWhalen.Controls = BillWhalen.Controls || {};
	BillWhalen.Controls.OpportunitySummary = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.OpportunitySummary;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}