/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./PipelineAttainment/index.ts":
/*!*************************************!*\
  !*** ./PipelineAttainment/index.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   PipelineAttainment: () => (/* binding */ PipelineAttainment)\n/* harmony export */ });\nclass PipelineAttainment {\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\n   */\n  init(context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._container = container;\n    this._notifyOutputChanged = notifyOutputChanged;\n    // Initialize the container\n    this.renderControl();\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   */\n  updateView(context) {\n    this._context = context;\n    this.renderControl();\n  }\n  /**\n   * Renders the Pipeline Attainment control\n   */\n  renderControl() {\n    // Clear existing content\n    this._container.innerHTML = '';\n    // Get property values\n    var boundGoalAmount = this._context.parameters.goalAmount.raw;\n    var staticGoalAmount = this._context.parameters.staticGoalAmount.raw || 0;\n    var goalAmount = boundGoalAmount !== null && boundGoalAmount !== undefined ? boundGoalAmount : staticGoalAmount;\n    var revenueAmount = this._context.parameters.revenueAmount.raw || 0;\n    var boundPeriodLabel = this._context.parameters.periodLabel.raw;\n    var staticPeriodLabel = this._context.parameters.staticPeriodLabel.raw || \"\";\n    var periodLabel = boundPeriodLabel !== null && boundPeriodLabel !== undefined && boundPeriodLabel !== \"\" ? boundPeriodLabel : staticPeriodLabel || \"Current Period\";\n    var themeColor = this._context.parameters.themeColor.raw || \"Blue\";\n    var customColor = this._context.parameters.customColor.raw || \"\";\n    var cardHeight = this._context.parameters.cardHeight.raw || 240;\n    console.log('Pipeline Attainment Debug:', {\n      boundGoalAmount,\n      staticGoalAmount,\n      goalAmount,\n      revenueAmount,\n      boundPeriodLabel,\n      staticPeriodLabel,\n      periodLabel,\n      themeColor,\n      customColor,\n      cardHeight\n    });\n    // Calculate metrics\n    var attainmentPercentage = goalAmount > 0 ? revenueAmount / goalAmount * 100 : 0;\n    var remainingAmount = Math.max(0, goalAmount - revenueAmount);\n    // Create main container\n    var mainContainer = document.createElement('div');\n    mainContainer.className = 'pipeline-attainment-container';\n    // Apply theme\n    this.applyStyling(mainContainer, themeColor, customColor, cardHeight);\n    // Create header section\n    var headerSection = document.createElement('div');\n    headerSection.className = 'attainment-header';\n    var periodLabelDiv = document.createElement('div');\n    periodLabelDiv.className = 'period-label';\n    periodLabelDiv.textContent = periodLabel;\n    headerSection.appendChild(periodLabelDiv);\n    var attainmentPercentageDiv = document.createElement('div');\n    attainmentPercentageDiv.className = 'attainment-percentage';\n    attainmentPercentageDiv.textContent = this.formatPercentage(attainmentPercentage);\n    headerSection.appendChild(attainmentPercentageDiv);\n    var attainmentLabelDiv = document.createElement('div');\n    attainmentLabelDiv.className = 'attainment-label';\n    attainmentLabelDiv.textContent = 'Goal Attainment';\n    headerSection.appendChild(attainmentLabelDiv);\n    mainContainer.appendChild(headerSection);\n    // Create metrics grid\n    var metricsGrid = document.createElement('div');\n    metricsGrid.className = 'metrics-grid';\n    // Goal Amount\n    var goalMetric = this.createMetricItem('Goal Amount', this.formatNumber(goalAmount));\n    metricsGrid.appendChild(goalMetric);\n    // Revenue Amount\n    var revenueMetric = this.createMetricItem('Revenue', this.formatNumber(revenueAmount));\n    metricsGrid.appendChild(revenueMetric);\n    // Remaining Amount (full width)\n    var remainingMetric = this.createMetricItem('Remaining', this.formatNumber(remainingAmount));\n    remainingMetric.className += ' remaining-amount';\n    metricsGrid.appendChild(remainingMetric);\n    mainContainer.appendChild(metricsGrid);\n    this._container.appendChild(mainContainer);\n  }\n  /**\n   * Creates a metric item element\n   */\n  createMetricItem(label, value) {\n    var metricItem = document.createElement('div');\n    metricItem.className = 'metric-item';\n    var metricLabel = document.createElement('div');\n    metricLabel.className = 'metric-label';\n    metricLabel.textContent = label;\n    metricItem.appendChild(metricLabel);\n    var metricValue = document.createElement('div');\n    metricValue.className = 'metric-value';\n    metricValue.textContent = value;\n    metricItem.appendChild(metricValue);\n    return metricItem;\n  }\n  /**\n   * Applies styling based on theme and custom color\n   */\n  applyStyling(container, themeColor, customColor, cardHeight) {\n    // Set card height\n    container.style.height = \"\".concat(cardHeight, \"px\");\n    // Apply theme class\n    var themeClass = \"theme-\".concat(themeColor.toLowerCase());\n    container.classList.add(themeClass);\n    // Apply custom color if specified\n    if (themeColor === \"Custom\" && customColor) {\n      var color = customColor.startsWith('#') ? customColor : \"#\".concat(customColor);\n      // Create a gradient with the custom color\n      var lighterColor = this.lightenColor(color, 20);\n      container.style.background = \"linear-gradient(135deg, \".concat(color, \" 0%, \").concat(lighterColor, \" 100%)\");\n    }\n  }\n  /**\n   * Lightens a hex color by a percentage\n   */\n  lightenColor(color, percent) {\n    var num = parseInt(color.replace(\"#\", \"\"), 16);\n    var amt = Math.round(2.55 * percent);\n    var R = (num >> 16) + amt;\n    var B = (num >> 8 & 0x00FF) + amt;\n    var G = (num & 0x0000FF) + amt;\n    return \"#\" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 + (B < 255 ? B < 1 ? 0 : B : 255) * 0x100 + (G < 255 ? G < 1 ? 0 : G : 255)).toString(16).slice(1);\n  }\n  /**\n   * Formats a number based on its type and value\n   */\n  formatNumber(value) {\n    if (value === 0) return '0';\n    // Check if the value looks like currency (large numbers)\n    if (Math.abs(value) >= 1000) {\n      var formatter = new Intl.NumberFormat('en-US', {\n        style: 'currency',\n        currency: 'USD',\n        minimumFractionDigits: 0,\n        maximumFractionDigits: 0\n      });\n      return formatter.format(value);\n    } else {\n      // Format as regular number for smaller values\n      var _formatter = new Intl.NumberFormat('en-US', {\n        minimumFractionDigits: 0,\n        maximumFractionDigits: 2\n      });\n      return _formatter.format(value);\n    }\n  }\n  /**\n   * Formats a number as currency (backwards compatibility)\n   */\n  formatCurrency(value) {\n    return this.formatNumber(value);\n  }\n  /**\n   * Formats a number as percentage\n   */\n  formatPercentage(value) {\n    if (value === 0) return '0%';\n    return \"\".concat(Math.round(value), \"%\");\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {};\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PipelineAttainment/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./PipelineAttainment/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('BillWhalen.Controls.PipelineAttainment', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PipelineAttainment);
} else {
	var BillWhalen = BillWhalen || {};
	BillWhalen.Controls = BillWhalen.Controls || {};
	BillWhalen.Controls.PipelineAttainment = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PipelineAttainment;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}